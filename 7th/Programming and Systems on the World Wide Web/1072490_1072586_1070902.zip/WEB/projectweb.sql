-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1:3307
-- Generation Time: Sep 16, 2024 at 02:20 PM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `projectweb`
--

-- --------------------------------------------------------

--
-- Table structure for table `announcements`
--

CREATE TABLE `announcements` (
  `id` int(11) NOT NULL,
  `title` varchar(255) NOT NULL,
  `description` text NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp()
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `announcements`
--

INSERT INTO `announcements` (`id`, `title`, `description`, `date`) VALUES
(1, 'Water', 'Water in category Food is needed.', '2024-09-09 13:14:12'),
(2, 'Orange juice', 'Orange juice in category Food is needed.', '2024-09-09 13:15:10'),
(10, 'Sardines', 'Sardines in category Food is needed.', '2024-09-09 13:36:19'),
(11, 'Canned corn', 'Canned corn in category Food is needed.', '2024-09-09 12:40:19'),
(12, 'Bread', 'Bread in category Food is needed.', '2024-09-09 12:40:28'),
(13, 'Chocolate', 'Chocolate in category Food is needed.', '2024-09-09 12:41:16'),
(14, 'Men Sneakers', 'Men Sneakers in category Clothing is needed.', '2024-09-09 12:44:44'),
(19, 'Biscuits', 'Biscuits in category Food is needed.', '2024-09-11 07:13:12'),
(20, 'Croissant', 'Croissant in category Food is needed.', '2024-09-11 07:13:15'),
(21, 'Spaghetti', 'Spaghetti in category Food is needed.', '2024-09-11 07:13:28'),
(22, 'Vitamin C', 'Vitamin C in category Medical Supplies is needed.', '2024-09-11 07:13:34');

-- --------------------------------------------------------

--
-- Table structure for table `items`
--

CREATE TABLE `items` (
  `id` int(11) NOT NULL,
  `category` varchar(50) NOT NULL,
  `name` varchar(50) NOT NULL,
  `quantity` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `locations`
--

CREATE TABLE `locations` (
  `id` int(11) NOT NULL,
  `lat` decimal(10,8) NOT NULL,
  `lng` decimal(11,8) NOT NULL,
  `type` varchar(50) NOT NULL,
  `description` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

-- --------------------------------------------------------

--
-- Table structure for table `offers`
--

CREATE TABLE `offers` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `date` timestamp NOT NULL DEFAULT current_timestamp(),
  `taken_up_date` datetime DEFAULT NULL,
  `executed_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `offers`
--

INSERT INTO `offers` (`id`, `user_id`, `product_name`, `quantity`, `status`, `date`, `taken_up_date`, `executed_date`) VALUES
(3, 6, 'Water', 3, 'pending', '2024-09-11 07:39:37', '2024-09-13 08:47:20', NULL),
(4, 16, 'Bread', 22, 'in progress', '2024-09-11 08:10:33', '2024-09-16 14:00:59', '2024-09-16 13:36:19'),
(5, 16, 'Chocolate', 26, 'pending', '2024-09-11 08:10:40', '2024-09-16 13:34:23', '2024-09-16 08:21:37'),
(6, 16, 'Water', 16, 'pending', '2024-09-11 08:10:47', '2024-09-13 12:02:28', '2024-09-13 12:02:49'),
(7, 16, 'Orange juice', 21, 'pending', '2024-09-11 08:10:54', '2024-09-13 15:36:17', NULL),
(8, 16, 'Men Sneakers', 20, 'fulfilled', '2024-09-11 08:11:00', '2024-09-16 14:14:59', '2024-09-16 14:15:20'),
(9, 16, 'Biscuits', 100, 'pending', '2024-09-11 08:14:11', '2024-09-13 14:32:09', '2024-09-13 14:32:22'),
(10, 16, 'Spaghetti', 40, 'pending', '2024-09-11 08:14:26', '2024-09-15 07:58:52', '2024-09-15 07:59:16'),
(11, 16, 'Croissant', 50, 'pending', '2024-09-11 08:14:28', '2024-09-12 14:13:11', NULL),
(12, 16, 'Vitamin C', 25, 'pending', '2024-09-11 08:14:40', '2024-09-12 14:12:11', NULL),
(15, 14, 'Canned corn', 16, 'pending', '2024-09-11 08:15:15', '2024-09-15 08:38:27', '2024-09-15 08:38:38'),
(16, 14, 'Bread', 18, 'pending', '2024-09-11 08:15:21', '2024-09-13 11:30:37', '2024-09-13 11:30:50'),
(17, 14, 'Chocolate', 25, 'pending', '2024-09-11 08:15:26', '2024-09-13 11:35:50', '2024-09-13 11:36:09'),
(18, 14, 'Men Sneakers', 17, 'pending', '2024-09-11 08:15:31', '2024-09-13 11:36:58', '2024-09-13 11:37:17'),
(19, 14, 'Spaghetti', 26, 'pending', '2024-09-11 08:15:37', '2024-09-13 11:47:09', '2024-09-13 11:47:34'),
(22, 2, 'Water', 100, 'pending', '2024-09-12 08:00:22', NULL, NULL),
(23, 2, 'Orange juice', 50, 'pending', '2024-09-12 08:10:18', NULL, NULL),
(24, 2, 'Orange juice', 50, 'pending', '2024-09-12 08:10:27', NULL, NULL),
(25, 2, 'Water', 100, 'pending', '2024-09-12 08:41:55', NULL, NULL),
(26, 2, 'Canned corn', 16, 'pending', '2024-09-12 10:10:45', NULL, NULL),
(27, 2, 'Canned corn', 16, 'pending', '2024-09-12 10:10:48', NULL, NULL),
(28, 2, 'Canned corn', 16, 'suspended', '2024-09-12 10:27:47', NULL, NULL),
(29, 2, 'Canned corn', 16, 'suspended', '2024-09-12 10:27:49', NULL, NULL),
(30, 2, 'Canned corn', 16, 'suspended', '2024-09-12 11:58:13', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `products`
--

CREATE TABLE `products` (
  `product_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `category` varchar(255) DEFAULT NULL,
  `details` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`details`)),
  `quantity` int(11) DEFAULT 0,
  `category_name` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `products`
--

INSERT INTO `products` (`product_id`, `product_name`, `category`, `details`, `quantity`, `category_name`) VALUES
(3, 'Potatoes', '5', '[{\"detail_name\":\"package\",\"detail_value\":\"20gr\"}]', 2, 'Food'),
(16, 'Water', '6', '[{\"detail_name\":\"volume\",\"detail_value\":\"1.5l\"},{\"detail_name\":\"pack size\",\"detail_value\":\"6\"}]', 232, 'Beverages'),
(17, 'Orange juice', '6', '[{\"detail_name\":\"volume\",\"detail_value\":\"250ml\"},{\"detail_name\":\"pack size\",\"detail_value\":\"12\"}]', 0, 'Beverages'),
(18, 'Sardines', '5', '[{\"detail_name\":\"brand\",\"detail_value\":\"Trata\"},{\"detail_name\":\"weight\",\"detail_value\":\"200g\"}]', 0, 'Food'),
(19, 'Canned corn', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"500g\"}]', 32, 'Food'),
(20, 'Bread', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"1kg\"},{\"detail_name\":\"type\",\"detail_value\":\"white\"}]', 32, 'Food'),
(21, 'Chocolate', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"100g\"},{\"detail_name\":\"type\",\"detail_value\":\"milk chocolate\"},{\"detail_name\":\"brand\",\"detail_value\":\"ION\"}]', 152, 'Food'),
(22, 'Men Sneakers', '7', '[{\"detail_name\":\"size\",\"detail_value\":\"44\"}]', 98, 'Clothing'),
(23, 'Test Product', '9', '[{\"detail_name\":\"weight\",\"detail_value\":\"500g\"},{\"detail_name\":\"pack size\",\"detail_value\":\"12\"},{\"detail_name\":\"expiry date\",\"detail_value\":\"13\\/12\\/1978\"}]', 0, '2d hacker'),
(24, 'Test Val', '14', '[{\"detail_name\":\"Details\",\"detail_value\":\"600ml\"}]', 0, 'Flood'),
(25, 'Spaghetti', '5', '[{\"detail_name\":\"grams\",\"detail_value\":\"500\"}]', 112, 'Food'),
(26, 'Croissant', '5', '[{\"detail_name\":\"calories\",\"detail_value\":\"200\"}]', 0, 'Food'),
(29, 'Biscuits', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 100, 'Food'),
(30, 'Bandages', '16', '[{\"detail_name\":\"\",\"detail_value\":\"25 pcs\"}]', 0, 'Medical Supplies'),
(31, 'Disposable gloves', '16', '[{\"detail_name\":\"\",\"detail_value\":\"100 pcs\"}]', 0, 'Medical Supplies'),
(32, 'Gauze', '16', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Medical Supplies'),
(33, 'Antiseptic', '16', '[{\"detail_name\":\"\",\"detail_value\":\"250ml\"}]', 0, 'Medical Supplies'),
(34, 'First Aid Kit', '16', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Medical Supplies'),
(35, 'Painkillers', '16', '[{\"detail_name\":\"volume\",\"detail_value\":\"200mg\"}]', 0, 'Medical Supplies'),
(36, 'Blanket', '7', '[{\"detail_name\":\"size\",\"detail_value\":\"50\\\" x 60\\\"\"}]', 0, 'Clothing'),
(37, 'Fakes', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Food'),
(38, 'Menstrual Pads', '21', '[{\"detail_name\":\"stock\",\"detail_value\":\"500\"},{\"detail_name\":\"size\",\"detail_value\":\"3\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Personal Hygiene'),
(39, 'Tampon', '21', '[{\"detail_name\":\"stock\",\"detail_value\":\"500\"},{\"detail_name\":\"size\",\"detail_value\":\"regular\"}]', 0, 'Personal Hygiene'),
(40, 'Toilet Paper', '21', '[{\"detail_name\":\"stock\",\"detail_value\":\"300\"},{\"detail_name\":\"ply\",\"detail_value\":\"3\"}]', 0, 'Personal Hygiene'),
(41, 'Baby wipes', '21', '[{\"detail_name\":\"volume\",\"detail_value\":\"500gr\"},{\"detail_name\":\"stock \",\"detail_value\":\"500\"},{\"detail_name\":\"scent\",\"detail_value\":\"aloe\"}]', 0, 'Personal Hygiene'),
(42, 'Toothbrush', '21', '[{\"detail_name\":\"stock\",\"detail_value\":\"500\"}]', 0, 'Personal Hygiene'),
(43, 'Toothpaste', '21', '[{\"detail_name\":\"stock\",\"detail_value\":\"250\"}]', 0, 'Personal Hygiene'),
(44, 'Vitamin C', '16', '[{\"detail_name\":\"stock\",\"detail_value\":\"200\"}]', 0, 'Medical Supplies'),
(45, 'Multivitamines', '16', '[{\"detail_name\":\"stock\",\"detail_value\":\"200\"}]', 0, 'Medical Supplies'),
(46, 'Paracetamol', '16', '[{\"detail_name\":\"stock\",\"detail_value\":\"2000\"},{\"detail_name\":\"dosage\",\"detail_value\":\"500mg\"}]', 0, 'Medical Supplies'),
(47, 'Ibuprofen', '16', '[{\"detail_name\":\"stock \",\"detail_value\":\"10\"},{\"detail_name\":\"dosage\",\"detail_value\":\"200mg\"}]', 0, 'Medical Supplies'),
(51, 'Cleaning rag', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(52, 'Detergent', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(53, 'Disinfectant', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(54, 'Mop', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(55, 'Plastic bucket', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(56, 'Scrub brush', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(57, 'Dust mask', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(58, 'Broom', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(59, 'Hammer', '23', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(60, 'Skillsaw', '23', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(61, 'Prybar', '23', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(62, 'Shovel', '23', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(63, 'Flashlight', '23', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(64, 'Duct tape', '23', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(65, 'Underwear', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(66, 'Socks', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(67, 'Warm Jacket', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(68, 'Raincoat', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(69, 'Gloves', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(70, 'Pants', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(71, 'Boots', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(72, 'Dishes', '24', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Kitchen Supplies'),
(73, 'Pots', '24', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Kitchen Supplies'),
(74, 'Paring knives', '24', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Kitchen Supplies'),
(75, 'Pan', '24', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Kitchen Supplies'),
(76, 'Glass', '24', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Kitchen Supplies'),
(83, 't22', '9', '[{\"detail_name\":\"wtwty\",\"detail_value\":\"wytwty\"}]', 0, '2d hacker'),
(84, 'water ', '6', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 232, 'Beverages'),
(85, 'Coca Cola', '6', '[{\"detail_name\":\"Volume\",\"detail_value\":\"500ml\"}]', 0, 'Beverages'),
(86, 'spray', '26', '[{\"detail_name\":\"volume\",\"detail_value\":\"75ml\"}]', 0, 'Insect Repellents'),
(87, 'Outdoor spiral', '26', '[{\"detail_name\":\"duration\",\"detail_value\":\"7 hours\"}]', 0, 'Insect Repellents'),
(88, 'Baby bottle', '25', '[{\"detail_name\":\"volume\",\"detail_value\":\"250ml\"}]', 0, 'Baby Essentials'),
(89, 'Pacifier', '25', '[{\"detail_name\":\"material\",\"detail_value\":\"silicone\"}]', 0, 'Baby Essentials'),
(90, 'Condensed milk', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"400gr\"}]', 0, 'Food'),
(91, 'Cereal bar', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"23,5gr\"}]', 0, 'Food'),
(92, 'Pocket Knife', '23', '[{\"detail_name\":\"Number of different tools\",\"detail_value\":\"3\"},{\"detail_name\":\"Tool\",\"detail_value\":\"Knife\"},{\"detail_name\":\"Tool\",\"detail_value\":\"Screwdriver\"},{\"detail_name\":\"Tool\",\"detail_value\":\"Spoon\"}]', 0, 'Tools'),
(93, 'Water Disinfection Tablets', '16', '[{\"detail_name\":\"Basic Ingredients\",\"detail_value\":\"Iodine\"},{\"detail_name\":\"Suggested for\",\"detail_value\":\"Everyone expept pregnant women\"}]', 0, 'Medical Supplies'),
(94, 'Radio', '27', '[{\"detail_name\":\"Power\",\"detail_value\":\"Batteries\"},{\"detail_name\":\"Frequencies Range\",\"detail_value\":\"3 kHz - 3000 GHz\"}]', 0, 'Electronic Devices'),
(95, 'Kitchen appliances', '14', '[{\"detail_name\":\"\",\"detail_value\":\"(scrubbers, rubber gloves, kitchen detergent, laundry soap)\"}]', 0, 'Flood'),
(96, 'Winter hat', '28', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cold weather'),
(97, 'Winter gloves', '28', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cold weather'),
(98, 'Scarf', '28', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cold weather'),
(99, 'Thermos', '28', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cold weather'),
(100, 'Tea', '6', '[{\"detail_name\":\"volume\",\"detail_value\":\"500ml\"}]', 0, 'Beverages'),
(101, 'Dog Food ', '29', '[{\"detail_name\":\"volume\",\"detail_value\":\"500g\"}]', 0, 'Animal Food'),
(102, 'Cat Food', '29', '[{\"detail_name\":\"volume\",\"detail_value\":\"500g\"}]', 0, 'Animal Food'),
(103, 'Canned', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Food'),
(104, 'Chlorine', '22', '[{\"detail_name\":\"volume\",\"detail_value\":\"500ml\"}]', 0, 'Cleaning Supplies'),
(105, 'Medical gloves', '22', '[{\"detail_name\":\"volume\",\"detail_value\":\"20pieces\"}]', 0, 'Cleaning Supplies'),
(106, 'T-Shirt', '7', '[{\"detail_name\":\"size\",\"detail_value\":\"XL\"}]', 0, 'Clothing'),
(107, 'Cooling Fan', '34', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(108, 'Cool Scarf', '34', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(109, 'Whistle', '23', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(110, 'Blankets', '28', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cold weather'),
(111, 'Sleeping Bag', '28', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cold weather'),
(112, 'Toothbrush', '21', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Personal Hygiene'),
(113, 'Toothpaste', '21', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Personal Hygiene'),
(114, 'Thermometer', '16', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Medical Supplies'),
(115, 'Rice', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Food'),
(116, 'Bread', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 32, 'Food'),
(117, 'Towels', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(118, 'Wet Wipes', '22', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Cleaning Supplies'),
(119, 'Fire Extinguisher', '23', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(120, 'Fruits', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Food'),
(121, 'Duct Tape', '23', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(123, 'Αθλητικά', '19', '[{\"detail_name\":\"\\u039d\\u03bf 46\",\"detail_value\":\"\"}]', 0, 'Shoes'),
(124, 'Πασατέμπος', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Food'),
(125, 'Bandages', '35', '[{\"detail_name\":\"Adhesive\",\"detail_value\":\"2 meters\"}]', 0, NULL),
(126, 'Betadine', '35', '[{\"detail_name\":\"Povidone iodine 10%\",\"detail_value\":\"240 ml\"}]', 0, NULL),
(127, 'cotton wool', '35', '[{\"detail_name\":\"100% Hydrofile\",\"detail_value\":\"70gr\"}]', 0, NULL),
(128, 'Crackers', '5', '[{\"detail_name\":\"Quantity per package\",\"detail_value\":\"10\"},{\"detail_name\":\"Packages\",\"detail_value\":\"2\"}]', 0, 'Food'),
(129, 'Sanitary Pads', '21', '[{\"detail_name\":\"piece\",\"detail_value\":\"10 pieces\"},{\"detail_name\":\"\",\"detail_value\":\"\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Personal Hygiene'),
(130, 'Sanitary wipes', '21', '[{\"detail_name\":\"pank\",\"detail_value\":\"10 packs\"}]', 0, 'Personal Hygiene'),
(131, 'Electrolytes', '16', '[{\"detail_name\":\"packet of pills\",\"detail_value\":\"20 pills\"}]', 0, 'Medical Supplies'),
(132, 'Pain killers', '16', '[{\"detail_name\":\"packet of pills\",\"detail_value\":\"20 pills\"}]', 0, 'Medical Supplies'),
(133, 'Flashlight', '23', '[{\"detail_name\":\"pieces\",\"detail_value\":\"1\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Tools'),
(134, 'Juice', '6', '[{\"detail_name\":\"volume\",\"detail_value\":\"500ml\"}]', 0, 'Beverages'),
(135, 'Toilet Paper', '21', '[{\"detail_name\":\"rolls\",\"detail_value\":\"1 roll\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Personal Hygiene'),
(136, 'Sterilized Saline', '16', '[{\"detail_name\":\"volume\",\"detail_value\":\"100ml\"}]', 0, 'Medical Supplies'),
(137, 'Biscuits', '5', '[{\"detail_name\":\"packet\",\"detail_value\":\"1 packet\"}]', 100, 'Food'),
(138, 'Antihistamines', '16', '[{\"detail_name\":\"pills\",\"detail_value\":\"10 pills\"}]', 0, 'Medical Supplies'),
(139, 'Instant Pancake Mix', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Food'),
(140, 'Lacta', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"105g\"}]', 0, 'Food'),
(141, 'Canned Tuna', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Food'),
(142, 'Batteries', '23', '[{\"detail_name\":\"6 pack\",\"detail_value\":\"\"}]', 0, 'Tools'),
(143, 'Dust Mask', '35', '[{\"detail_name\":\"1\",\"detail_value\":\"\"}]', 0, NULL),
(144, 'Can Opener', '23', '[{\"detail_name\":\"1\",\"detail_value\":\"\"}]', 0, 'Tools'),
(146, 'Πατατάκια', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"45g\"}]', 0, 'Food'),
(147, 'Σερβιέτες', '21', '[{\"detail_name\":\"pcs\",\"detail_value\":\"18\"}]', 0, 'Personal Hygiene'),
(148, 'Dry Cranberries', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"100\"}]', 0, 'Food'),
(149, 'Dry Apricots', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"100\"}]', 0, 'Food'),
(150, 'Dry Figs', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"100\"}]', 0, 'Food'),
(151, 'Παξιμάδια', '5', '[{\"detail_name\":\"weight\",\"detail_value\":\"200g\"}]', 0, 'Food'),
(153, 'Test Item', '11', '[{\"detail_name\":\"volume\",\"detail_value\":\"200g\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Test'),
(154, 'Painkillers', '35', '[{\"detail_name\":\"Potency\",\"detail_value\":\"High\"}]', 0, NULL),
(155, 'Tampons', '16', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Medical Supplies'),
(156, 'plaster set', '41', '[{\"detail_name\":\"1\",\"detail_value\":\"\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(157, 'elastic bandages', '41', '[{\"detail_name\":\"\",\"detail_value\":\"12\"}]', 0, NULL),
(158, 'traumaplast', '41', '[{\"detail_name\":\"\",\"detail_value\":\"20\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(159, 'thermal blanket', '41', '[{\"detail_name\":\"\",\"detail_value\":\"2\"}]', 0, NULL),
(160, 'burn gel', '41', '[{\"detail_name\":\"ml\",\"detail_value\":\"500\"}]', 0, NULL),
(161, 'pet carrier', '41', '[{\"detail_name\":\"\",\"detail_value\":\"2\"}]', 0, NULL),
(162, 'pet dishes', '41', '[{\"detail_name\":\"\",\"detail_value\":\"10\"}]', 0, NULL),
(163, 'plastic bags', '41', '[{\"detail_name\":\"\",\"detail_value\":\"20\"}]', 0, NULL),
(164, 'toys', '41', '[{\"detail_name\":\"\",\"detail_value\":\"5\"}]', 0, NULL),
(165, 'burn pads', '41', '[{\"detail_name\":\"\",\"detail_value\":\"5\"}]', 0, NULL),
(166, 'cheese', '5', '[{\"detail_name\":\"grams\",\"detail_value\":\"1000\"}]', 0, 'Food'),
(167, 'lettuce', '5', '[{\"detail_name\":\"grams\",\"detail_value\":\"500\"}]', 0, 'Food'),
(168, 'eggs', '5', '[{\"detail_name\":\"pair\",\"detail_value\":\"10\"}]', 0, 'Food'),
(169, 'steaks', '5', '[{\"detail_name\":\"grams\",\"detail_value\":\"1000\"}]', 0, 'Food'),
(170, 'beef burgers', '5', '[{\"detail_name\":\"grams\",\"detail_value\":\"500\"}]', 0, 'Food'),
(171, 'tomatoes', '5', '[{\"detail_name\":\"grams\",\"detail_value\":\"1000\"}]', 0, 'Food'),
(172, 'onions', '5', '[{\"detail_name\":\"grams\",\"detail_value\":\"500\"}]', 0, 'Food'),
(173, 'flour', '5', '[{\"detail_name\":\"grams\",\"detail_value\":\"1000\"}]', 0, 'Food'),
(174, 'pastel', '5', '[{\"detail_name\":\"\",\"detail_value\":\"7\"}]', 0, 'Food'),
(175, 'nuts', '5', '[{\"detail_name\":\"grams\",\"detail_value\":\"500\"}]', 0, 'Food'),
(176, 'dramamines', '42', '[{\"detail_name\":\"\",\"detail_value\":\"5\"}]', 0, NULL),
(177, 'nurofen', '42', '[{\"detail_name\":\"\",\"detail_value\":\"10\"}]', 0, NULL),
(178, 'imodium', '42', '[{\"detail_name\":\"\",\"detail_value\":\"5\"}]', 0, NULL),
(179, 'emetostop', '42', '[{\"detail_name\":\"\",\"detail_value\":\"5\"}]', 0, NULL),
(180, 'xanax', '42', '[{\"detail_name\":\"\",\"detail_value\":\"5\"}]', 0, NULL),
(181, 'saflutan', '42', '[{\"detail_name\":\"\",\"detail_value\":\"2\"}]', 0, NULL),
(182, 'sadolin', '42', '[{\"detail_name\":\"\",\"detail_value\":\"3\"}]', 0, NULL),
(183, 'depon', '42', '[{\"detail_name\":\"\",\"detail_value\":\"20\"}]', 0, NULL),
(184, 'panadol', '42', '[{\"detail_name\":\"\",\"detail_value\":\"6\"}]', 0, NULL),
(185, 'ponstan ', '42', '[{\"detail_name\":\"\",\"detail_value\":\"10\"}]', 0, NULL),
(186, 'algofren', '42', '[{\"detail_name\":\"10\",\"detail_value\":\"600ml\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(187, 'effervescent depon', '42', '[{\"detail_name\":\"67\",\"detail_value\":\"1000mg\"}]', 0, NULL),
(188, 'cold coffee', '6', '[{\"detail_name\":\"10\",\"detail_value\":\"330ml\"}]', 0, 'Beverages'),
(189, 'Hell', '43', '[{\"detail_name\":\"22\",\"detail_value\":\"330\"}]', 0, NULL),
(190, 'Monster', '43', '[{\"detail_name\":\"31\",\"detail_value\":\"500ml\"}]', 0, NULL),
(191, 'Redbull', '43', '[{\"detail_name\":\"40\",\"detail_value\":\"330ml\"}]', 0, NULL),
(192, 'Powerade', '43', '[{\"detail_name\":\"23\",\"detail_value\":\"500ml\"}]', 0, NULL),
(193, 'PRIME', '43', '[{\"detail_name\":\"15\",\"detail_value\":\"500ml\"}]', 0, NULL),
(194, 'Lighter', '23', '[{\"detail_name\":\"16\",\"detail_value\":\"Mini\"}]', 0, 'Tools'),
(195, 'isothermally shirts', '28', '[{\"detail_name\":\"5\",\"detail_value\":\"Medium\"},{\"detail_name\":\"6\",\"detail_value\":\"Large\"},{\"detail_name\":\"10\",\"detail_value\":\"Small\"},{\"detail_name\":\"2\",\"detail_value\":\"XL\"}]', 0, 'Cold weather'),
(197, 'Depon', '42', '[{\"detail_name\":\"10\",\"detail_value\":\"500mg\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(198, 'Shorts', '34', '[{\"detail_name\":\"20\",\"detail_value\":\"\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(199, 'Chicken', '5', '[{\"detail_name\":\"5\",\"detail_value\":\"1.5kg\"}]', 0, 'Food'),
(200, 'Toilet Paper', '21', '[{\"detail_name\":\"20\",\"detail_value\":\"200g\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Personal Hygiene'),
(201, 'toys', '41', '[{\"detail_name\":\"30\",\"detail_value\":\"\"}]', 0, NULL),
(202, 'sanitary napkins', '21', '[{\"detail_name\":\"30\",\"detail_value\":\"500g\"}]', 0, 'Personal Hygiene'),
(203, 'COVID-19 Tests', '16', '[{\"detail_name\":\"20\",\"detail_value\":\"\"}]', 0, 'Medical Supplies'),
(204, 'Club Soda', '6', '[{\"detail_name\":\"volume\",\"detail_value\":\"500ml\"}]', 0, 'Beverages'),
(205, 'Wheelchairs', '44', '[{\"detail_name\":\"quantity\",\"detail_value\":\"100\"}]', 0, NULL),
(206, 'mobile phones', '45', '[{\"detail_name\":\"iphone\",\"detail_value\":\"200\"}]', 0, NULL),
(207, 'spoon', '24', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Kitchen Supplies'),
(208, 'fork', '24', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Kitchen Supplies'),
(209, 'MOTOTRBO R7', '45', '[{\"detail_name\":\"band\",\"detail_value\":\"UHF\\/VHF\"},{\"detail_name\":\"Wi-Fi\",\"detail_value\":\"2,4\\/5,0 GHz\"},{\"detail_name\":\"Bluetooth\",\"detail_value\":\"5.2\"},{\"detail_name\":\"\\u039f\\u03b8\\u03cc\\u03bd\\u03b7\",\"detail_value\":\"2,4\\u201d 320 x 240 px. QVGA\"},{\"detail_name\":\"\\u03b4\\u03b9\\u03ac\\u03c1\\u03ba\\u03b5\\u03b9\\u03b1 \\u03b6\\u03c9\\u03ae\\u03c2 \\u03c4\\u03b7\\u03c2 \\u03bc\\u03c0\\u03b1\\u03c4\\u03b1\\u03c1\\u03af\\u03b1\\u03c2\",\"detail_value\":\"28 \\u03ce\\u03c1\\u03b5\\u03c2\"}]', 0, NULL),
(210, 'RM LA 250 (VHF Linear Ενισχυτής 140-150MHz)', '45', '[{\"detail_name\":\"Frequency\",\"detail_value\":\"140-150Mhz\"},{\"detail_name\":\"Power Supply\",\"detail_value\":\"13VDC \\/- 1V 40A\"},{\"detail_name\":\"Output RF Power (Nominal)\",\"detail_value\":\"30 \\u2013 210W ; 230W max AM\\/FM\\/CW\"},{\"detail_name\":\"Modulation Types\",\"detail_value\":\"SSB,CW,AM, FM, data etc (All narrowband modes)\"}]', 0, NULL),
(211, 'Humanitarian General Purpose Tent System (HGPTS)', '47', '[{\"detail_name\":\"PART NUMBER\",\"detail_value\":\"C14Y016X016-T\"},{\"detail_name\":\"CONTRACTOR NAME:\",\"detail_value\":\"CELINA Tent, Inc\"},{\"detail_name\":\"COLOR\",\"detail_value\":\"Tan\"},{\"detail_name\":\"SET-UP TIME\\/NUMBER OF PERSONS\",\"detail_value\":\"4 People\\/30 Minutes\"}]', 0, NULL),
(212, 'CELINA Dynamic Small Shelter ', '47', '[{\"detail_name\":\"dimensions\",\"detail_value\":\" 20\\u2019x32.5\\u2019\"},{\"detail_name\":\"TYPE\",\"detail_value\":\"Frame Structure, Expandable, Air-Transportable\"},{\"detail_name\":\"WEIGHT\",\"detail_value\":\"1,200 lbs\"}]', 0, NULL),
(213, 'Multi-purpose Area Shelter System, Type-I', '47', '[{\"detail_name\":\"TYPE\",\"detail_value\":\"Frame Structure, Expandable, Air- Transportable\"},{\"detail_name\":\"DIMENSIONS\",\"detail_value\":\"E I-40\\u2019x80\\u2019\"},{\"detail_name\":\"WEIGHT\",\"detail_value\":\"24,000 lbs\"}]', 0, NULL),
(214, 'Trousers', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(215, 'Shoes', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(216, 'Hoodie', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(218, 'dog food', '49', '[{\"detail_name\":\"weight\",\"detail_value\":\"1k\"}]', 0, NULL),
(219, 'cat food', '49', '[{\"detail_name\":\"weight\",\"detail_value\":\"1k\"}]', 0, NULL),
(220, 'macaroni', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Food'),
(221, 'rice', '5', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Food'),
(222, 'scarf', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(223, 'gloves', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(224, 'underwear', '7', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Clothing'),
(225, 'Silver blanket', '50', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(226, 'Helmet', '50', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(227, 'Disposable toilet', '50', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(228, 'Self-generated flashlight', '50', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(229, 'Mattresses ', '51', '[{\"detail_name\":\"size\",\"detail_value\":\"1.90X60\"}]', 0, NULL),
(230, 'flashlight', '51', '[{\"detail_name\":\"light\",\"detail_value\":\"blue\"}]', 0, NULL),
(231, 'matches', '51', '[{\"detail_name\":\"pack\",\"detail_value\":\"60\"}]', 0, NULL),
(232, 'Heater', '51', '[{\"detail_name\":\"Volts\",\"detail_value\":\"208\"}]', 0, NULL),
(233, 'Earplugs', '51', '[{\"detail_name\":\"material\",\"detail_value\":\"plastic\"}]', 0, NULL),
(234, 'Compass', '52', '[{\"detail_name\":\"Type\",\"detail_value\":\"Digital\"}]', 0, NULL),
(235, 'Map', '52', '[{\"detail_name\":\"Material\",\"detail_value\":\"Paper\"}]', 0, NULL),
(236, 'GPS', '52', '[{\"detail_name\":\"Type\",\"detail_value\":\"Waterproof\"}]', 0, NULL),
(237, 'First Aid', '16', '[{\"detail_name\":\"1\",\"detail_value\":\"1\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Medical Supplies'),
(238, 'Bandage', '16', '[{\"detail_name\":\"\",\"detail_value\":\"5\"}]', 0, 'Medical Supplies'),
(239, 'Mask', '16', '[{\"detail_name\":\"\",\"detail_value\":\"10\"}]', 0, 'Medical Supplies'),
(240, 'Medicines', '16', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Medical Supplies'),
(241, 'Water', '5', '[{\"detail_name\":\"6\",\"detail_value\":\"1500ml\"}]', 232, 'Food'),
(242, 'Canned Goods', '5', '[{\"detail_name\":\"2\",\"detail_value\":\"80g\"}]', 0, 'Food'),
(243, 'Snacks', '5', '[{\"detail_name\":\"3\",\"detail_value\":\"100g\"}]', 0, 'Food'),
(244, 'Cereals', '5', '[{\"detail_name\":\"1\",\"detail_value\":\"800g\"}]', 0, 'Food'),
(245, 'Blankets', '53', '[{\"detail_name\":\"1\",\"detail_value\":\"\"}]', 0, NULL),
(246, 'Shirt', '53', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(247, 'Pants', '53', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(248, 'Shoes', '53', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(249, 'Socks', '53', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(250, 'Caps', '53', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(251, 'Gloves', '53', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(252, 'Flashlight', '54', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(253, 'Batteries', '54', '[{\"detail_name\":\"AAA\",\"detail_value\":\"5\"}]', 0, NULL),
(254, 'Repair Tools', '54', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(255, 'Soap and Shampoo', '21', '[{\"detail_name\":\"1\",\"detail_value\":\"200ml\"}]', 0, 'Personal Hygiene'),
(256, 'Toothpastes and Toothbrushes', '21', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Personal Hygiene'),
(257, 'Towels', '21', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Personal Hygiene'),
(258, 'Diapers', '56', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(259, 'Animal food', '56', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(260, 'Pots', '57', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(261, 'Plates', '57', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(262, 'Cups', '57', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(263, 'Cutlery ', '57', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(264, 'Cleaning Supplies', '57', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(265, 'Kitchen Appliances', '57', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(266, 'Home Repair Tools', '57', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(268, 'Lord of the Rings', '59', '[{\"detail_name\":\"pages\",\"detail_value\":\"230\"}]', 0, NULL),
(269, 'Dog Food', '29', '[{\"detail_name\":\"\",\"detail_value\":\"1kg\"}]', 0, 'Animal Food'),
(270, 'DEPON', '16', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Medical Supplies'),
(271, 'Painkillers', '16', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, 'Medical Supplies'),
(272, 'Gasoline', '60', '[{\"detail_name\":\"galons\",\"detail_value\":\"20\"}]', 0, NULL),
(273, 'Power Banks', '60', '[{\"detail_name\":\"quantity\",\"detail_value\":\"5\"}]', 0, NULL),
(275, 'test item', '29', '[{\"detail_name\":\"test item \",\"detail_value\":\"1kg\"}]', 0, 'Animal Food'),
(276, 'test item2', '61', '[{\"detail_name\":\"volume\",\"detail_value\":\"500ml\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(277, 'T4 Levothyroxine', '42', '[{\"detail_name\":\"pills\",\"detail_value\":\"60 pills\"}]', 0, NULL),
(279, 'Solar Charger', '67', '[{\"detail_name\":\"\",\"detail_value\":\"\"},{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(280, 'Solar-Powered Radio', '67', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(281, 'Solar Torch', '67', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(282, 'Stress Ball', '68', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(283, 'Guided Meditation Audio', '68', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(286, 'Frezyderm Baby Bath ', '69', '[{\"detail_name\":\"volume\",\"detail_value\":\"700ml\"}]', 0, NULL),
(287, 'Love me again ', '59', '[{\"detail_name\":\"pages\",\"detail_value\":\"654\"}]', 0, NULL),
(288, 'Apotel', '16', '[{\"detail_name\":\"mg\",\"detail_value\":\"100\"}]', 0, 'Medical Supplies'),
(289, 'Xanax', '16', '[{\"detail_name\":\"mg\",\"detail_value\":\"5mg\"}]', 0, 'Medical Supplies'),
(290, 'Medrol', '16', '[{\"detail_name\":\"mg\",\"detail_value\":\"16\"}]', 0, 'Medical Supplies'),
(291, 'Nike shoes', '19', '[{\"detail_name\":\"size\",\"detail_value\":\"42\"}]', 0, 'Shoes'),
(292, 'Petrol', '70', '[{\"detail_name\":\"Volume\",\"detail_value\":\"2L\"}]', 0, NULL),
(293, 'Tires', '70', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(294, 'Car Oil', '70', '[{\"detail_name\":\"Volume\",\"detail_value\":\"1L\"}]', 0, NULL),
(295, 'Brake Fluid', '70', '[{\"detail_name\":\"Volume\",\"detail_value\":\"1L\"}]', 0, NULL),
(296, 'Car Battery', '70', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(297, 'Windshield Wipers', '70', '[{\"detail_name\":\"\",\"detail_value\":\"\"}]', 0, NULL),
(448, 'Potatos1', '5', '[{\"detail_name\":\"package\",\"detail_value\":\"30gr\"}]', 1232, 'Food');

-- --------------------------------------------------------

--
-- Table structure for table `requests`
--

CREATE TABLE `requests` (
  `id` int(11) NOT NULL,
  `user_id` int(11) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` varchar(50) DEFAULT 'pending',
  `product_name` varchar(255) DEFAULT NULL,
  `request_date` timestamp NOT NULL DEFAULT current_timestamp(),
  `taken_up_date` datetime DEFAULT NULL,
  `executed_date` datetime DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `requests`
--

INSERT INTO `requests` (`id`, `user_id`, `quantity`, `status`, `product_name`, `request_date`, `taken_up_date`, `executed_date`) VALUES
(5, 13, 2, 'pending', 'Water', '2024-09-11 08:07:25', '2024-09-16 12:48:43', NULL),
(6, 13, 2, 'pending', 'Bread', '2024-09-11 08:07:33', '2024-09-16 12:49:20', NULL),
(7, 13, 2, 'pending', 'Chocolate', '2024-09-11 08:07:41', NULL, NULL),
(8, 13, 2, 'pending', 'Spaghetti', '2024-09-11 08:07:49', '2024-09-16 09:47:33', '2024-09-16 09:45:41'),
(13, 15, 3, 'pending', 'Orange juice', '2024-09-11 08:09:37', '2024-09-16 14:00:03', NULL),
(14, 15, 3, 'pending', 'Spaghetti', '2024-09-11 08:09:53', '2024-09-16 14:13:18', '2024-09-16 14:05:49'),
(15, 15, 3, 'fulfilled', 'Men Sneakers', '2024-09-11 08:10:01', '2024-09-16 14:16:49', '2024-09-16 14:17:24'),
(16, 15, 3, 'pending', 'Vitamin C', '2024-09-11 08:10:12', '2024-09-16 13:51:17', NULL),
(17, 6, 5, 'pending', 'Potatoes', '2024-09-11 09:29:59', NULL, NULL),
(18, 6, 5, 'pending', 'Chocolate', '2024-09-11 09:30:05', NULL, NULL),
(19, 6, 5, 'pending', 'Bandages', '2024-09-11 09:30:11', NULL, NULL),
(20, 6, 5, 'pending', 'First Aid Kit', '2024-09-11 09:30:21', NULL, NULL);

-- --------------------------------------------------------

--
-- Table structure for table `rescuers`
--

CREATE TABLE `rescuers` (
  `rescuer_id` int(11) NOT NULL,
  `username` varchar(255) NOT NULL,
  `password` varchar(255) NOT NULL,
  `coordinates` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `rescuers`
--

INSERT INTO `rescuers` (`rescuer_id`, `username`, `password`, `coordinates`) VALUES
(2, 'konstantinos', '', '{\"initial_position\":[\"38.244940279498\",\"21.742921834706\"],\"random_position\":[\"38.2454730708982\",\"21.739557922196703\"],\"final_position\":[\"38.24593567324251\",\"21.736637165945236\"]}'),
(11, 'dimitris', '', '{\"initial_position\":[\"38.249762102903\",\"21.735032515363\"],\"random_position\":[\"38.24723838640991\",\"21.735568947863662\"],\"final_position\":[\"38.246942457718745\",\"21.735631849448776\"]}'),
(12, 'giannis', '', '{\"initial_position\":[\"38.241549946235\",\"21.729369583349\"],\"random_position\":[\"38.241792178151385\",\"21.72971552637752\"],\"final_position\":[\"38.245678107045514\",\"21.73526520798105\"]}');

-- --------------------------------------------------------

--
-- Table structure for table `tasks`
--

CREATE TABLE `tasks` (
  `id` int(11) NOT NULL,
  `rescuer_id` int(11) NOT NULL,
  `product_name` varchar(255) NOT NULL,
  `quantity` int(11) NOT NULL,
  `status` varchar(50) NOT NULL,
  `source` varchar(255) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `tasks`
--

INSERT INTO `tasks` (`id`, `rescuer_id`, `product_name`, `quantity`, `status`, `source`) VALUES
(224, 2, 'Men Sneakers', 3, 'fulfilled', 'request'),
(225, 2, 'Men Sneakers', 20, 'fulfilled', 'offer'),
(226, 2, 'Men Sneakers', 3, 'fulfilled', 'request');

-- --------------------------------------------------------

--
-- Table structure for table `users`
--

CREATE TABLE `users` (
  `id` int(11) NOT NULL,
  `username` varchar(50) NOT NULL,
  `password` varchar(255) NOT NULL,
  `fullname` varchar(100) NOT NULL,
  `phone` varchar(15) NOT NULL,
  `role` enum('admin','rescuer','citizen') NOT NULL,
  `coordinates` longtext CHARACTER SET utf8mb4 COLLATE utf8mb4_bin DEFAULT NULL CHECK (json_valid(`coordinates`))
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `users`
--

INSERT INTO `users` (`id`, `username`, `password`, `fullname`, `phone`, `role`, `coordinates`) VALUES
(1, 'admin', 'admin', 'admin', '6948500552', 'admin', NULL),
(2, 'konstantinos', '123', 'konstantinos', '6953200114', 'rescuer', '{\"lat\":\"38.241084398582096\",\"lng\":\"21.736254058471893\"}'),
(6, 'Palaiologos', '12345', 'konstantinos', '5841222223', 'citizen', '{\"lat\":\"38.261820\",\"lng\":\"21.750346\"}'),
(11, 'dimitris', '123', 'dimitris Rescuer', '6953200114', 'rescuer', '{\"lat\":\"38.24705989396793\",\"lng\":\"21.735713751294888\"}'),
(12, 'giannis', '123', 'Giannis Rescuer', '6945300115', 'rescuer', '{\"lat\":\"38.24618753891762\",\"lng\":\"21.728819345892063\"}'),
(13, 'papadopoulos', '12345', 'Konstantinos papadopoulos', '5841222223', 'citizen', '{\"lat\":\"38.241670\",\"lng\":\"21.744254\"}'),
(14, 'marinakis', '12345', 'Vasileios Marinakis', '5841234523', 'citizen', '{\"lat\":\"38.243857\",\"lng\":\"21.744213\"}'),
(15, 'nikolakopoulos', '12345', 'Nikolaos Nikolakopoulos', '5841356789', 'citizen', '{\"lat\":\"38.241125\",\"lng\":\"21.732354\"}'),
(16, 'petrakis', '12345', 'Georgios Petrakis', '5841567891', 'citizen', '{\"lat\":\"38.249976\",\"lng\":\"21.741532\"}');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `announcements`
--
ALTER TABLE `announcements`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `title` (`title`);

--
-- Indexes for table `items`
--
ALTER TABLE `items`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `locations`
--
ALTER TABLE `locations`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `offers`
--
ALTER TABLE `offers`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `products`
--
ALTER TABLE `products`
  ADD PRIMARY KEY (`product_id`);

--
-- Indexes for table `requests`
--
ALTER TABLE `requests`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `rescuers`
--
ALTER TABLE `rescuers`
  ADD PRIMARY KEY (`rescuer_id`);

--
-- Indexes for table `tasks`
--
ALTER TABLE `tasks`
  ADD PRIMARY KEY (`id`);

--
-- Indexes for table `users`
--
ALTER TABLE `users`
  ADD PRIMARY KEY (`id`),
  ADD UNIQUE KEY `username` (`username`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `announcements`
--
ALTER TABLE `announcements`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- AUTO_INCREMENT for table `items`
--
ALTER TABLE `items`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `locations`
--
ALTER TABLE `locations`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT;

--
-- AUTO_INCREMENT for table `offers`
--
ALTER TABLE `offers`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=31;

--
-- AUTO_INCREMENT for table `requests`
--
ALTER TABLE `requests`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;

--
-- AUTO_INCREMENT for table `rescuers`
--
ALTER TABLE `rescuers`
  MODIFY `rescuer_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=40;

--
-- AUTO_INCREMENT for table `tasks`
--
ALTER TABLE `tasks`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=227;

--
-- AUTO_INCREMENT for table `users`
--
ALTER TABLE `users`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=18;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
