import pandas as pd
import numpy as np
from bs4 import BeautifulSoup
import requests
import random
import os.path


NAMES_URL = "https://en.wikipedia.org/wiki/List_of_computer_scientists"
FIELDS_URL = "https://en.wikipedia.org/wiki/Outline_of_computer_science"


html_doc = requests.get(NAMES_URL)
soup = BeautifulSoup(html_doc.content, "html.parser")
data_div = soup.find("div", "mw-parser-output")

initial_letter = ""
cs_names = []
first_names = []

for el in data_div.find_all(["li", "h2"]):
    if el.name == "h2":
        initial_letter = el.span.string
    else:
        name = el.a.string
        segs = name.split()
        if segs[-1].title().startswith(initial_letter):
            fname = segs[-1]
        else:
            fname = segs[0]

        cs_names.append(name)
        first_names.append(fname)

f = cs_names.index("Atta ur Rehman Khan")
t = cs_names.index("Konrad Zuse")

cs_names = cs_names[f:t+1]
first_names = first_names[f:t+1]

html_doc = requests.get(FIELDS_URL)
soup = BeautifulSoup(html_doc.content, "html.parser")
data_div = soup.find("div", "mw-parser-output")

cs_fields = [li.a.string for li in data_div.find_all("li")]
cs_fields = list(filter(lambda x: not x.startswith("List"), filter(None, cs_fields)))
cs_fields = cs_fields[cs_fields.index("Coding theory"):
                      cs_fields.index("Quantum computing")+1]

# warning: fake data!

SEED = 12345
np.random.seed(SEED)
random.seed(SEED)
# create random number of awards
awards = list(map(lambda x: max(int(x), 0), np.random.normal(8, 3, size=len(cs_names))))

# create random education for each scientist
education = [", ".join(random.sample(cs_fields, k=random.randint(5, 8))).lower()
             for _ in range(len(cs_names))]



df = pd.DataFrame({
    "full_names": cs_names,
    "Surname": first_names,
    "#Awards": awards,
    "Education": education
})

# write output to file
df.to_csv(os.path.join("data", "scientists.tsv"), index=False, sep='\t')

print(len(cs_fields))
