import hashlib
import compare_utils as cu

class RTreeNode:
    def __init__(self, is_leaf=False, children=None, MBR=None):
        self.is_leaf = is_leaf
        self.children = children if children else []
        self.MBR = MBR

class RTree:
    def __init__(self, items):
        self.max_entries = 4
        self.root = RTreeNode(is_leaf=True)
        for i, row in items.iterrows():
            self.insert(i, [cu.RangeData(row["Surname"], row["Surname"]+"a"),
                            cu.RangeData(row["#Awards"], row["#Awards"]+0.1)])

    def insert(self, point, MBR):
        node = self._choose_leaf(self.root, MBR)
        node.children.append((point, MBR))
        self._split_node(node)

    def _choose_leaf(self, node, MBR):
        if node.is_leaf:
            return node
        min_enlargement = float("inf")
        best_child = None
        for child in node.children:
            child_MBR = child[1]
            enlargement = self._calculate_enlargement(MBR, child_MBR)
            if enlargement < min_enlargement:
                min_enlargement = enlargement
                best_child = child[0]
        return self._choose_leaf(best_child, MBR)

    def _split_node(self, node):
        if len(node.children) <= self.max_entries:
            return
        seeds = self._get_seeds(node)
        groups = [[], []]
        for child in node.children:
            if child == seeds[0] or child == seeds[1]:
                continue
            min_enlargement = float("inf")
            best_group = None
            for group in groups:
                enlargement = self._calculate_enlargement(child[1], node.MBR)
                if enlargement < min_enlargement:
                    min_enlargement = enlargement
                    best_group = group
            best_group.append(child)
        node.children = [RTreeNode(children=group) for group in groups]

    def _get_seeds(self, node):
        max_distance = 0
        seeds = [None, None]
        for i in range(len(node.children)):
            for j in range(i + 1, len(node.children)):
                child1 = node.children[i]
                child2 = node.children[j]
                distance = self._calculate_distance(child1.MBR, child2.MBR)
                if distance > max_distance:
                    max_distance = distance
                    seeds = [child1, child2]
        return seeds

    def _calculate_distance(self, MBR1, MBR2):
        return abs(ord(MBR1[0].low[0]) - ord(MBR2[0].low[0])) + abs(MBR1[1].low - MBR2[1].low)

    def _calculate_enlargement(self, MBR1, MBR2):
        if MBR1 is None or MBR2 is None:
            return 0

        return abs(ord(MBR1[0].low[0]) - ord(MBR2[0].low[0])) + abs(MBR1[1].low - MBR2[1].low)

    def range_search(self, region):
        return self._range_query(self.root, region)

    def _range_query(self, node, region):
        if node.is_leaf:
            return [child for child in node.children if cu.compare_range(child[1], region) == cu.RANGE_INTERCEPT]
        results = []
        for child in node.children:
            if cu.compare_range(child[1], region) == cu.RANGE_INTERCEPT:
                results.extend(self._range_query(child[0], region))
        return results
