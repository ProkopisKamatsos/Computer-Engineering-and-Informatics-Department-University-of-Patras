RANGE_NINF = "ninf"
RANGE_INF  = "inf"

EQUAL = 0
LESS_THAN = -1
MORE_THAN = 1

RANGE_SUBRANGE = 1
RANGE_INTERCEPT = 2
RANGE_NORANGE = 3

def compare_all(a, b):
    if a == b:
        return EQUAL
    elif a == RANGE_NINF:
        return LESS_THAN
    elif a == RANGE_INF:
        return MORE_THAN
    elif b == RANGE_NINF:
        return MORE_THAN
    elif b == RANGE_INF:
        return LESS_THAN
    elif a < b:
        return LESS_THAN
    else:
        return MORE_THAN


class RangeData:

    def __init__(self, l, h):
        self.low = l
        self.high = h


def compare_range(ra, rb):
    state = RANGE_SUBRANGE
    for dima, dimb in zip(ra, rb):
        down = compare_all(dima.low, dimb.low)
        up   = compare_all(dima.high, dimb.high)

        if compare_all(dima.high, dimb.low) == LESS_THAN or compare_all(dima.low, dimb.high) == MORE_THAN:
            return RANGE_NORANGE
        elif compare_all(dima.low, dimb.low) == LESS_THAN or compare_all(dima.high, dimb.high) == MORE_THAN:
            state = RANGE_INTERCEPT

    return state

