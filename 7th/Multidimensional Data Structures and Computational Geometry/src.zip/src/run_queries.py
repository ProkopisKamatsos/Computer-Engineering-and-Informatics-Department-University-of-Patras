import pandas as pd
import os
import compare_utils as cu
from functools import partial
from lsh import *

from kd_tree import KDTree

MIN_HASHES = 20
BUCKETS = 10
# read the data
scientists = pd.read_csv(os.path.join("data", "scientists.tsv"), sep='\t')
index_columns = ("Surname", "#Awards")

# precalculate shingles
scientists["education_shingles"] = scientists["Education"].apply(shingle)

# create vocabulary
vocabulary = list(set().union(*scientists["education_shingles"]))
vocab_index = {shingle: idx for idx, shingle in enumerate(vocabulary)}

scientists["education_onehot"] = scientists["education_shingles"].apply(partial(create_onehot, vocab_index=vocab_index))
min_hash = create_min_hash(MIN_HASHES, len(vocabulary))
# ["lsh_signature"] = df["education_onehot"].apply(partial(compute_signature, min_hash=min_hash))

print("all records", len(scientists))
kd = KDTree(scientists, index_columns)


def print_results(results):
    print(scientists[["Surname", "#Awards", "Education"]].iloc[results])


# print(signatures[0])

def query(index_tree, query_range, similarity_threshold):
    res = index_tree.range_search(query_range)
    signatures = scientists["education_onehot"].iloc[res].apply(partial(compute_signature, min_hash=min_hash))
    similar = compute_candiadate_index_pairs(signatures, BUCKETS)

    results = []
    for sa, sb in similar:
        ga = res[sa]
        gb = res[sb]

        similarity = jaccard_onehots(*scientists["education_onehot"].iloc[[ga, gb]])
        if similarity >= similarity_threshold:
            results.append((ga, gb, similarity))

    return results


def print_query_results(results):
    for ga, gb, similarity in results:
        print(ga, scientists["Surname"][ga], scientists["Education"][ga])
        print(gb, scientists["Surname"][gb], scientists["Education"][gb])
        print(f"Similarity: {similarity*100:.2f}%")


test_range = [cu.RangeData("A", "Brooks"), cu.RangeData(0, 5)]
qr = query(kd, test_range, 0.60)
print_query_results(qr)

