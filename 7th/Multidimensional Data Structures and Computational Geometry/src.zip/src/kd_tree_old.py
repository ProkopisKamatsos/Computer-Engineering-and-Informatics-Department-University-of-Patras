import numpy as np
import pandas as pd
import compare_utils as cu


class KDNode:

    node_count = 0
    indexed_nodes = 0
    def __init__(self, tree, indexes, depth=0, forward_count=0):
        KDNode.node_count += 1
        self.tree = tree
        self.axis = depth % len(self.tree.axis_list)
        self.axis_name = self.tree.axis_list[self.axis]
        # next_axis = (self.axis+1) % len(self.tree.axis_list)

        self.right_child = None
        self.left_child = None

        if forward_count == len(tree.axis_list):
            self.terminal_node = True
            self.terminal_values = indexes[self.axis]
            KDNode.indexed_nodes += len(self.terminal_values)
            return


        self.median_index = len(indexes[self.axis]) // 2
        if len(indexes[self.axis]) % 2 == 0:
            self.median_index -= 1
        self.median_value = tree.dataset[self.axis_name][indexes[self.axis][self.median_index]]
        self.terminal_node = len(indexes[self.axis]) == 1

        if self.terminal_node:
            self.terminal_values = indexes[self.axis]
            KDNode.indexed_nodes += len(self.terminal_values)
            return

        # print(f"depth={depth} axis{self.axis_name} median_value={self.median_value} tnode {self.terminal_node}")

        # create new index lists
        left_indexes = []
        right_indexes = []
        for ax_idx, ax_name in enumerate(tree.axis_list):
            l = []
            r = []
            for i_pos in indexes[ax_idx]:
                if tree.dataset[self.axis_name][i_pos] <= self.median_value:
                    l.append(i_pos)
                else:
                    r.append(i_pos)

            left_indexes.append(l)
            right_indexes.append(r)

            # print(f"Split {ax_name}: {len(l)} | {len(r)}")

        if len(left_indexes[self.axis]) == 0:
            # print("forwarding")
            self.right_child = KDNode(self.tree, indexes, depth+1, forward_count+1)
            self.left_child = None
        elif len(right_indexes[self.axis]) == 0:
            self.left_child = KDNode(self.tree, indexes, depth+1, forward_count+1)
            self.right_child = None
        else:
            self.left_child  = KDNode(self.tree, left_indexes, depth+1)
            self.right_child = KDNode(self.tree, right_indexes, depth+1)


    def report_subtree(self):
        if self.terminal_node:
            return self.terminal_values

        ret = []
        if self.left_child is not None:
            ret.extend(self.left_child.report_subtree())

        if self.right_child is not None:
            ret.extend(self.right_child.report_subtree())

        return ret

    def range_search(self, range_data, current_range):
        left_range = [cu.RangeData(r.low, r.high) for r in current_range]
        left_range[self.axis].high = self.median_value
        right_range = [cu.RangeData(r.low, r.high) for r in current_range]
        right_range[self.axis].low = self.median_value

        results = []
        el_range = [cu.RangeData(self.tree.dataset[ax][self.median_index], self.tree.dataset[ax][self.median_index]) for ax in self.tree.axis_list]
        if self.terminal_node and cu.compare_range(el_range, range_data) == cu.RANGE_SUBRANGE:
            return self.terminal_values

        if self.left_child is not None:
            lcr = cu.compare_range(left_range, range_data)
            if lcr == cu.RANGE_SUBRANGE:
                results.extend(self.left_child.report_subtree())
            elif lcr == cu.RANGE_INTERCEPT:
                results.extend(self.left_child.range_search(range_data, left_range))

        if self.right_child is not None:
            rcr = cu.compare_range(right_range, range_data)
            if rcr == cu.RANGE_SUBRANGE:
                results.extend(self.right_child.report_subtree())
            elif rcr == cu.RANGE_INTERCEPT:
                results.extend(self.right_child.range_search(range_data, right_range))


        return results


class KDTree:

    def __init__(self, dataset, axis_list):
        # pre-sort indexes for each col
        self.dataset = dataset
        self.axis_list = axis_list
        indexes = [self.dataset[axis].argsort() for axis in self.axis_list]

        # build kd tree
        self.root = KDNode(self, indexes)

    def range_search(self, range_data):
        c_range = [cu.RangeData(cu.RANGE_NINF, cu.RANGE_INF) for _ in range(len(self.axis_list))]

        return self.root.range_search(range_data, c_range)




