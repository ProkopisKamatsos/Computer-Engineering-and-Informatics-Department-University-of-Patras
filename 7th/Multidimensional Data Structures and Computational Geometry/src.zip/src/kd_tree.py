import numpy as np
import pandas as pd
import compare_utils as cu


class KDNode:

    node_count = 0
    indexed_nodes = 0
    def __init__(self, tree, items, depth=0, forward_count=0):
        KDNode.node_count += 1
        self.tree = tree
        self.axis = depth % len(self.tree.axis_list)
        self.axis_name = self.tree.axis_list[self.axis]

        self.right_child = None
        self.left_child = None

        # find median based on axis
        items.sort(key=lambda x:self.tree.dataset[self.axis_name][x])
        median_index = len(items) // 2

        self.median_value = self.tree.dataset[self.axis_name][items[median_index]]
        self.median = items[median_index]
        KDNode.indexed_nodes += 1

        # create new index lists
        left_items = items[:median_index]
        right_items = items[median_index+1:]

        if len(left_items) > 0:
            self.left_child = KDNode(self.tree, left_items, depth+1)

        if len(right_items) > 0:
            self.right_child = KDNode(self.tree, right_items, depth+1)



    def report_subtree(self):
        ret = [self.median]
        if self.left_child is not None:
            ret.extend(self.left_child.report_subtree())

        if self.right_child is not None:
            ret.extend(self.right_child.report_subtree())

        return ret

    def range_search(self, range_data, current_range):
        left_range = [cu.RangeData(r.low, r.high) for r in current_range]
        left_range[self.axis].high = self.median_value
        right_range = [cu.RangeData(r.low, r.high) for r in current_range]
        right_range[self.axis].low = self.median_value

        el_range = [cu.RangeData(self.tree.dataset[ax][self.median], self.tree.dataset[ax][self.median]) for ax in self.tree.axis_list]
        results = []
        if cu.compare_range(el_range, range_data) == cu.RANGE_SUBRANGE:
            results.append(self.median)

        if self.left_child is not None:
            lcr = cu.compare_range(left_range, range_data)
            if lcr == cu.RANGE_SUBRANGE:
                results.extend(self.left_child.report_subtree())
            elif lcr == cu.RANGE_INTERCEPT:
                results.extend(self.left_child.range_search(range_data, left_range))

        if self.right_child is not None:
            rcr = cu.compare_range(right_range, range_data)
            if rcr == cu.RANGE_SUBRANGE:
                results.extend(self.right_child.report_subtree())
            elif rcr == cu.RANGE_INTERCEPT:
                results.extend(self.right_child.range_search(range_data, right_range))


        return results


class KDTree:

    def __init__(self, dataset, axis_list):
        # pre-sort indexes for each col
        self.dataset = dataset
        self.axis_list = axis_list
        indexes = list(range(len(self.dataset)))

        # build kd tree
        self.root = KDNode(self, indexes)

    def range_search(self, range_data):
        c_range = [cu.RangeData(cu.RANGE_NINF, cu.RANGE_INF) for _ in range(len(self.axis_list))]

        return self.root.range_search(range_data, c_range)




