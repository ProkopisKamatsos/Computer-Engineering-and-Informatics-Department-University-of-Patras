import pandas as pd
import numpy as np
from functools import partial
from itertools import combinations
import os

def jaccard(a: set, b: set):
    return len(a.intersection(b)) / len(a.union(b))

def jaccard_onehots(a, b):
    return sum(map(all, zip(a, b))) / sum(map(any, zip(a, b)))

dataset_path = os.path.join("data", "scientists.tsv")

# load dataset
df = pd.read_csv(dataset_path, sep='\t')

# create LSH vocabulary
# data = df["Education"].str.split(", ")

# create shingles
def shingle(text, k=2):
    shingle_set = []
    for i in range(len(text) - k+1):
        shingle_set.append(text[i:i+k])
    return set(shingle_set)

def create_onehot(shingles, vocab_index):
    onehot = np.zeros(len(vocab_index), dtype=np.uint8)
    for shingle in shingles:
        onehot[vocab_index[shingle]] = 1

    return onehot


def create_hash_line(length):
    hash_line = np.arange(length)
    np.random.shuffle(hash_line)
    return hash_line


def create_min_hash(min_hashes, length):
    return [create_hash_line(length) for _ in range(min_hashes)]


def compute_signature(vector, min_hash):
    sig = np.zeros(len(min_hash), dtype=int)

    for sig_idx, hash_line in enumerate(min_hash):
        for idx, vec_idx in enumerate(hash_line):
            if vector[vec_idx] == 1:
                sig[sig_idx] = idx
                break

    return sig

def split_signature_to_buckets(sig, buckets):
    bucket_size, rem = divmod(len(sig), buckets)
    if rem != 0:
       buckets += 1

    sig_buckets = []
    for bi, i in enumerate(range(0, len(sig), bucket_size)):
        end = i+bucket_size
        if bi == buckets-1:
            end = len(sig)
        sig_buckets.append(sig[i:end])

    return sig_buckets

# precalculate shingles
# df["education_shingles"] = df["Education"].apply(shingle)
# 
# # create vocabulary
# vocabulary = list(set().union(*df["education_shingles"]))
# vocab_index = {shingle: idx for idx, shingle in enumerate(vocabulary)}
# 
# df["education_onehot"] = df["education_shingles"].apply(partial(create_onehot, vocab_index=vocab_index))
# 
# MIN_HASHES = 20
# BUCKETS = 10
# 
# min_hash = create_min_hash(MIN_HASHES, len(vocabulary))
# df["lsh_signature"] = df["education_onehot"].apply(partial(compute_signature, min_hash=min_hash))

# print(df.iloc[0])
# print(split_signature_to_buckets(df.iloc[0]["lsh_signature"], BUCKETS), sep='\n')
# print(compute_signature(test_vec, minhash))
# print(df.head())

def compute_candiadate_index_pairs(min_hashes, n_buckets):
    buckets = [dict() for _ in range(n_buckets)]

    for mhi, min_hash in enumerate(min_hashes):
        min_hash_spiltted = split_signature_to_buckets(min_hash, n_buckets)
        for si, segment in enumerate(min_hash_spiltted):
            key = '-'.join(map(str, segment))
            if key not in buckets[si]:
                buckets[si][key] = list()

            buckets[si][key].append(mhi)

    candidate_pairs = set()
    for bucket in buckets:
        for sames in bucket.values():
            for pair in combinations(sames, 2):
                candidate_pairs.add(pair)


    return list(candidate_pairs)

