
class QuadTreeNode:

    def __init__(self, tree, item_index, range_x, range_y):
        self.tree = tree
        self.index = index
        self.range_x = range_x
        self.range_y = range_y`

        self.points = []
        self.children = []
        
    def insert(self, item_index):
        if len(self.children) > 0:
            index = self.get_index(item_index)
            if index != -1:
                self.children[index].insert(item_index)
                return
        self.points.append((x, y))
        if len(self.points) > 4:
            self.subdivide()
            
    def get_index(self, item_index):
        vertical_midpoint = self.x + self.width / 2
        horizontal_midpoint = self.y + self.height / 2
        top_quadrant = (y < horizontal_midpoint and x < vertical_midpoint)
        bottom_quadrant = (y >= horizontal_midpoint and x < vertical_midpoint)
        if top_quadrant:
            return 1
        elif bottom_quadrant:
            return 2
        else:
            horizontal_midpoint = self.y + self.height / 2
            if y < horizontal_midpoint:
                return 0
            else:
                return 3
            
    def subdivide(self):
        quarter_width = self.width / 4
        quarter_height = self.height / 4
        x = self.x
        y = self.y
        self.children.append(Node(x, y, quarter_width, quarter_height))
        self.children.append(Node(x + quarter_width, y, quarter_width, quarter_height))
        self.children.append(Node(x, y + quarter_height, quarter_width, quarter_height))
        self.children.append(Node(x + quarter_width, y + quarter_height, quarter_width, quarter_height))
        for point in self.points:
            index = self.get_index(point)
            self.children[index].insert(point)
        self.points = []
        
    def query_range(self, x_range, y_range):
        x_min, x_max = map(float, x_range.split(","))
        y_min, y_max = map(float, y_range.split(","))
        results = []
        if x_min <= self.x + self.width and x_max >= self.x and y_min <= self.y + self.height and y_max >= self.y:
            for point in self.points:
                if x_min <= point[0] <= x_max and y_min <= point[1] <= y_max:
                    results.append(point)
            for child in self.children:
                results += child.query_range(x_range, y_range)
        return results


class QuadTree:

    def __init__(self, dataset, axis_list):
        self.dataset = dataset
        self.axis_list = axis_list
