:- dynamic(pos/3).

pos(0,b,true).
pos(0,w,true).
pos(0,e,true).

pos(1,b,true).
pos(1,w,false).
pos(1,e,false).

pos(2,b,false).
pos(2,w,true).
pos(2,e,false).

pos(3,b,true).
pos(3,w,false).
pos(3,e,false).

pos(4,b,false).
pos(4,w,false).
pos(4,e,true).

pos(5,b,false).
pos(5,w,true).
pos(5,e,false).

pos(6,b,true).
pos(6,w,false).
pos(6,e,false).

pos(7,b,false).
pos(7,w,true).
pos(7,e,false).

pos(8,b,true).
pos(8,w,true).
pos(8,e,true).

make_line :- write('---------------').

make_pos :- write('|'),pos(1,X,true),write(X), write('|'),
		 pos(2,Y,true),write(Y), write('|'),
		 pos(3,Z,true),write(Z), write('|'),
		 pos(4,K,true),write(K), write('|'),
		 pos(5,L,true),write(L), write('|'),
		 pos(6,F,true),write(F), write('|'),
		 pos(7,M,true),write(M), write('|').

make_box :- make_line,nl,make_pos,nl,make_line.

go_right(X) :-  pos(X,Y,true), X1 is X+1, X2 is X+2,pos(X1,Y1,true),pos(X2,Y2,true),
		     (Y1==e, retract(pos(X,Y,true)), assert(pos(X,e,true)),
				 retract(pos(X1,e,true)), assert(pos(X1,Y,true)); 

			Y2==e, retract(pos(X,Y,true)), assert(pos(X,e,true)),
				 retract(pos(X2,e,true)), assert(pos(X2,Y,true)); 

			write('Cannot perform operation')	
			).

go_left(X) :-  pos(X,Y,true), X1 is X-1, X2 is X-2,pos(X1,Y1,true),pos(X2,Y2,true),
		     (Y1==e, retract(pos(X,Y,true)), assert(pos(X,e,true)),
				 retract(pos(X1,e,true)), assert(pos(X1,Y,true)); 

			Y2==e, retract(pos(X,Y,true)), assert(pos(X,e,true)),
				 retract(pos(X2,e,true)), assert(pos(X2,Y,true)); 

			write('Cannot perform operation')	
			).



