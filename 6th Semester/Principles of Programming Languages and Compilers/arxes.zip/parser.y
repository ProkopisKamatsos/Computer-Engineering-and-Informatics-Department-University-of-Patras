%{
#include <stdio.h>
#include <stdlib.h>
#include <string.h>


extern int line_number;
extern char* yytext();
int yylex();


void yyerror( char *strcmd);
FILE *yyin;

%}


%token LINEARLAYOUT TLINEARLAYOUT RELATIVELAYOUT TRELATIVELAYOUT Androidlayout_width Androidlayout_height
%token Androidid Androidorientation TEXTVIEW  IMAGEVIEW BUTTON RADIOBUTTON RADIOGROUP TRADIOGROUP PROGRESSBAR 
%token AndroidtextColor Androidtext Androidsrc Androidpadding AndroidcheckedButton Androidprogress Androidmax
%token ENDTAG STRING INTEGER NUMBER

%%

riza: layout ;
layout: linearlayout | relativelayout;
linearlayout: LINEARLAYOUT widthheight op1 '>' elements TLINEARLAYOUT;
relativelayout: RELATIVELAYOUT widthheight op2 '>' elements TRELATIVELAYOUT;
widthheight: 	Androidlayout_width '=' val1 Androidlayout_height '=' val1 | 
	 	Androidlayout_height '=' val1 Androidlayout_width '=' val1;

val1: STRING | INTEGER;
op1: | Androidid '=' STRING | Androidorientation '=' STRING | 
	Androidid '=' STRING Androidorientation '=' STRING |
	 Androidorientation '=' STRING Androidid '=' STRING; 
op2: |  Androidid '=' STRING ;

elements: element |  elements element;
element: textview |  imageview | button | radiogroup | progressbar | linearlayout | relativelayout;

textview: TEXTVIEW widthheight op3 ENDTAG;
op3: 	Androidtext '=' STRING | 
	Androidtext '=' STRING Androidid '=' STRING|
	Androidid '=' STRING Androidtext '=' STRING |
	Androidtext '=' STRING AndroidtextColor '=' STRING|
	AndroidtextColor '=' STRING Androidtext '=' STRING|
	Androidtext '=' STRING Androidid '=' STRING AndroidtextColor '=' STRING|
	Androidid '=' STRING Androidtext '=' STRING  AndroidtextColor '=' STRING|
	Androidid '=' STRING AndroidtextColor '=' STRING Androidtext '=' STRING  ;
	
imageview: IMAGEVIEW widthheight op4 ENDTAG;
op4: 	Androidsrc '=' STRING | 
	Androidsrc '=' STRING Androidid '=' STRING|
	Androidid '=' STRING Androidsrc '=' STRING |
	Androidsrc '=' STRING Androidpadding '=' INTEGER|
	Androidpadding  '=' INTEGER Androidtext '=' STRING|
	Androidsrc '=' STRING Androidid '=' STRING Androidpadding '=' STRING|
	Androidid '=' STRING Androidsrc '=' STRING  Androidpadding '=' INTEGER |
	Androidid '=' STRING Androidpadding '=' INTEGER Androidsrc '=' STRING  ;
	
	
button: BUTTON widthheight op5 ENDTAG;
op5: 	Androidtext '=' STRING | 
	Androidtext '=' STRING Androidid '=' STRING|
	Androidid '=' STRING Androidtext '=' STRING |
	Androidtext '=' STRING Androidpadding '=' STRING|
	Androidpadding '=' STRING Androidtext '=' STRING|
	Androidtext '=' STRING Androidid '=' STRING Androidpadding '=' STRING|
	Androidid '=' STRING Androidtext '=' STRING  Androidpadding '=' STRING|
	Androidid '=' STRING Androidpadding '=' STRING Androidtext '=' STRING  ;
	
radiogroup: 	RADIOGROUP widthheight op6 '>' radiobuttons TRADIOGROUP;
op6: 	| Androidid '=' STRING|
	AndroidcheckedButton '=' STRING |
	Androidid '=' STRING AndroidcheckedButton '=' STRING|
	AndroidcheckedButton '=' STRING Androidid '=' STRING   ;
	
radiobuttons: 	radiobutton| radiobuttons radiobutton;
radiobutton: RADIOBUTTON widthheight op7 ENDTAG;
op7: 	Androidtext '=' STRING | 
	Androidtext '=' STRING Androidid '=' STRING|
	Androidid '=' STRING Androidtext '=' STRING ;
	

progressbar: PROGRESSBAR widthheight op8 ENDTAG;
op8: | op81;	 
op81:  Androidid '=' STRING | Androidmax '=' STRING | Androidprogress '=' STRING
	op81 Androidid '=' STRING |
	op81 Androidmax '=' STRING |
	op81 Androidprogress '=' STRING ;
	
		

%%

void yyerror( char *strcmd)
{
       
       printf("Error line %d !\n", line_number );
	   
       exit(1);
	   
	   
      		
}

void main(int argc, char *argv[]){
	FILE *f;
	
	
	f=fopen(argv[1],"r");
	
	yyin = f; 	
	yyparse(); 	
	fclose(f);
	
	printf("Syntax is correct !!!! \n");
	
	exit(0);
	
	
}


